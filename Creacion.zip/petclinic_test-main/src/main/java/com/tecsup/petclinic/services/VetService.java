package com.tecsup.petclinic.services;

import com.tecsup.petclinic.entities.Pet;

import java.util.List;

/**
 * 
 * @author jgomezm
 *
 */
public interface VetService {

	/**
	 * 
	 * @param pet
	 * @return
	 */
	Pet create(Pet pet);

	List<Pet> findAll();
}