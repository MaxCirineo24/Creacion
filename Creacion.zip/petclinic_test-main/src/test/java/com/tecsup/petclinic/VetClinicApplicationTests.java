package com.tecsup.petclinic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class VetClinicApplicationTests {

	@Test
	public void contextLoads() {
	}

}
